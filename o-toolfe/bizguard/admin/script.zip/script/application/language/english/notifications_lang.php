<?php

defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

$lang['notify_ticket_assigned_department'] = 'A new ticket has been assigned to one of your departments.';
$lang['notify_ticket_assigned']            = 'A new ticket has been assigned to you.';
$lang['notify_user_replied_ticket']        = 'The user has replied to the ticket that\'s assigned to you.';
$lang['notify_agent_replied_ticket']       = 'Your ticket has been replied to by our agent.';

// @version 1.4
$lang['notify_chat_assigned_department']   = 'A new chat has been assigned to one of your departments.';
$lang['notify_chat_assigned']              = 'A new chat has been assigned to you.';

// @version 2.0
$lang['notify_ticket_feedback_shared']     = 'The user shared the feedback to the ticket that\'s assigned to you.';
